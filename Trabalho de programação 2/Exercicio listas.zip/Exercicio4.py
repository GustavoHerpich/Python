planetas = ["Mercúrio", "Vênus", "Terra", "Marte", "Saturno", "Júpiter", "Urano", "Netuno"]
planetas[4] = "Fobos", "Deimos"
planetas[0] = "Sol"
print(planetas)