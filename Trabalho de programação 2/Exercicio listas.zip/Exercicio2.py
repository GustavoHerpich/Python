lista = []
for i in range(0, 100):
    lista.append(i)
print(lista[99::-3])
print(lista[87:35:-1])
print(lista[:98])

